



""" 
backend knowledge
YS: 50-100 hr 
NO: 0-10 hr
<<: 100-200 hr 
>>: 10-50 hr


 """